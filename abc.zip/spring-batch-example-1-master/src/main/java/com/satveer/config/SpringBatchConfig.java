package com.satveer.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.satveer.model.User;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

    @Bean
    public Job job(JobBuilderFactory jobBuilderFactory,
                   StepBuilderFactory stepBuilderFactory,
                   ItemReader<User> itemReader,
                   ItemProcessor<User, User> itemProcessor,
                   ItemWriter<User> itemWriter
    ) {

        Step step = stepBuilderFactory.get("CSV-file-load")
                .<User, User>chunk(100)
                .reader(itemReader)
                .processor(itemProcessor)
                .writer(itemWriter)
                .build();


        return jobBuilderFactory.get("CSV-Load")
                .incrementer(new RunIdIncrementer())
                .start(step)
                .build();
    }

  /*  @Bean
    @StepScope
    public FlatFileItemReader<User> itemReader() {

        FlatFileItemReader<User> flatFileItemReader = new FlatFileItemReader<User>();
        flatFileItemReader.setResource(new FileSystemResource("src/main/resources/users2.csv"));
        //flatFileItemReader.setName("CSV-Reader");
        //flatFileItemReader.setLinesToSkip(1);
        //flatFileItemReader.setLineMapper(lineMapper());
        FixedLengthTokenizer fixedLengthTookenizer = new FixedLengthTokenizer();//id,name,dept,salary
        fixedLengthTookenizer.setNames("id","name", "dept", "salary");
        fixedLengthTookenizer.setColumns(new Range[]{new Range(1), new Range(2), new Range(7), new Range(10)});
        //fixedLengthTookenizer.setNames("data");
        //fixedLengthTookenizer.setColumns(new Range[] {new Range(1,17)});
        //1 Peter 001 12000
        //12345678901234567
        
        //1Peter00112000
        //12345678901234
        DefaultLineMapper<User> lineMapper = new DefaultLineMapper<User>();
        lineMapper.setLineTokenizer(fixedLengthTookenizer);
        flatFileItemReader.setLineMapper(lineMapper);
        
        return flatFileItemReader;
    }*/
    
    @Bean
    public FlatFileItemReader<User> fixLengthItemReader(){
        FlatFileItemReader<User> reader = new FlatFileItemReader<User>();
        reader.setResource(new FileSystemResource("src/main/resources/users2.csv"));
        reader.setLineMapper(new DefaultLineMapper<User>() {
            {
                setLineTokenizer(fixedLengthTokenizer());
                setFieldSetMapper(new BeanWrapperFieldSetMapper<User>() {
                    {
                        setTargetType(User.class);
                    }
                });
            }
        });
        return reader;
    }
    
    @Bean
    public FixedLengthTokenizer fixedLengthTokenizer() {
        FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
        //1 Peter 001 12000
        //12345678901234567
        tokenizer.setColumns(new Range[] { new Range(1, 2), new Range(3, 8), new Range(9, 12), new Range(13, 17) });
        tokenizer.setNames(new String[] { "id", "name", "dept", "salary" });
        tokenizer.setStrict(false);
        return tokenizer;
    }

    @Bean
    public LineMapper<User> lineMapper() {

        DefaultLineMapper<User> defaultLineMapper = new DefaultLineMapper<User>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();

        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames("id", "name", "dept", "salary");

        BeanWrapperFieldSetMapper<User> fieldSetMapper = new BeanWrapperFieldSetMapper<User>();
        fieldSetMapper.setTargetType(User.class);
        fieldSetMapper.setStrict(false);

        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }

}
